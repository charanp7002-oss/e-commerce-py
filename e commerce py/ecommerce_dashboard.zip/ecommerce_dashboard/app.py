"""Shopper behavior dashboard: Flask backend that serves analysis from pandas."""
from pathlib import Path

import pandas as pd
from flask import Flask, Response, jsonify, render_template, request

BASE = Path(__file__).parent
app = Flask(__name__)

# ---------- Load and prepare the data once at start-up ----------
df = pd.read_csv(BASE / "data" / "ecommerce_customer_behavior_dataset.csv", parse_dates=["Date"])
df["Month"] = df["Date"].dt.to_period("M").astype(str)
df["Age_Group"] = pd.cut(df["Age"], [17, 24, 34, 44, 54, 120],
                         labels=["18-24", "25-34", "35-44", "45-54", "55+"]).astype(str)
df["Gross_Amount"] = df["Unit_Price"] * df["Quantity"]
df["Customer_Type"] = df["Is_Returning_Customer"].map({True: "Returning", False: "New"})

FILTERS = {"category": "Product_Category", "city": "City", "device": "Device_Type", "gender": "Gender"}
TABLE_COLS = ["Order_ID", "Date", "City", "Product_Category", "Quantity",
              "Total_Amount", "Payment_Method", "Device_Type", "Customer_Rating"]


def filtered() -> pd.DataFrame:
    """Apply the filters sent by the browser (query string) to the dataset."""
    d = df
    for arg, col in FILTERS.items():
        if request.args.get(arg):
            d = d[d[col] == request.args[arg]]
    if request.args.get("start"):
        d = d[d["Date"] >= request.args["start"]]
    if request.args.get("end"):
        d = d[d["Date"] <= request.args["end"]]
    return d


def series(s: pd.Series, digits: int = 2) -> dict:
    return {"labels": [str(i) for i in s.index], "values": [round(float(v), digits) for v in s.values]}


def build_insights(d: pd.DataFrame) -> list[str]:
    """Plain-language findings computed from whatever slice is selected."""
    out = []
    total = d["Total_Amount"].sum()

    cat = d.groupby("Product_Category")["Total_Amount"].sum().sort_values(ascending=False)
    if len(cat) > 1:
        out.append(f"{cat.index[0]} brings in {cat.iloc[0] / total:.0%} of revenue, "
                   f"while {cat.index[-1]} brings in only {cat.iloc[-1] / total:.0%}.")

    city = d.groupby("City")["Total_Amount"].sum().sort_values(ascending=False)
    if len(city) > 1:
        out.append(f"{city.index[0]} is the strongest city with {city.iloc[0] / total:.0%} of revenue.")

    disc = d["Discount_Amount"] > 0
    if disc.any() and (~disc).any():
        out.append(f"{disc.mean():.0%} of orders used a discount. Discounted orders average "
                   f"{d.loc[disc, 'Total_Amount'].mean():,.0f} versus {d.loc[~disc, 'Total_Amount'].mean():,.0f} without one.")

    ret = d.groupby("Customer_Type")["Total_Amount"].mean()
    if {"New", "Returning"} <= set(ret.index):
        gap = ret["Returning"] / ret["New"] - 1
        out.append(f"Returning customers spend {abs(gap):.0%} {'more' if gap >= 0 else 'less'} per order than new customers.")

    if len(d) > 2:
        r = d["Delivery_Time_Days"].corr(d["Customer_Rating"])
        if pd.notna(r):
            strength = "barely relates to" if abs(r) < 0.1 else "is linked to"
            out.append(f"Delivery time {strength} customer rating (correlation {r:+.2f}).")

    dev = d["Device_Type"].value_counts(normalize=True)
    if len(dev):
        out.append(f"{dev.index[0]} is the most used device, with {dev.iloc[0]:.0%} of orders.")
    return out


# ---------- Pages and API ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/meta")
def meta():
    return jsonify({
        "category": sorted(df["Product_Category"].unique()),
        "city": sorted(df["City"].unique()),
        "device": sorted(df["Device_Type"].unique()),
        "gender": sorted(df["Gender"].unique()),
        "start": df["Date"].min().strftime("%Y-%m-%d"),
        "end": df["Date"].max().strftime("%Y-%m-%d"),
    })


@app.route("/api/dashboard")
def dashboard():
    d = filtered()
    if d.empty:
        return jsonify({"empty": True})

    gross = d["Gross_Amount"].sum()
    kpis = {
        "revenue": round(d["Total_Amount"].sum(), 2),
        "orders": int(len(d)),
        "aov": round(d["Total_Amount"].mean(), 2),
        "rating": round(d["Customer_Rating"].mean(), 2),
        "returning": round(d["Is_Returning_Customer"].mean() * 100, 1),
        "discount_rate": round(d["Discount_Amount"].sum() / gross * 100, 1),
        "delivery": round(d["Delivery_Time_Days"].mean(), 1),
    }
    monthly = d.groupby("Month").agg(revenue=("Total_Amount", "sum"), orders=("Order_ID", "count"))
    delivery_bins = pd.cut(d["Delivery_Time_Days"], [0, 2, 4, 6, 8, 10, 100],
                           labels=["1-2", "3-4", "5-6", "7-8", "9-10", "11+"])
    return jsonify({
        "empty": False,
        "kpis": kpis,
        "monthly": {"labels": list(monthly.index), "revenue": monthly["revenue"].round(2).tolist(),
                    "orders": monthly["orders"].tolist()},
        "category": series(d.groupby("Product_Category")["Total_Amount"].sum().sort_values(ascending=False)),
        "city": series(d.groupby("City")["Total_Amount"].sum().sort_values(ascending=False)),
        "payment": series(d["Payment_Method"].value_counts()),
        "device": series(d["Device_Type"].value_counts()),
        "age": series(d.groupby("Age_Group")["Total_Amount"].mean().reindex(
            ["18-24", "25-34", "35-44", "45-54", "55+"]).dropna()),
        "rating": series(d["Customer_Rating"].value_counts().reindex([1, 2, 3, 4, 5], fill_value=0), 0),
        "delivery_rating": series(d.groupby(delivery_bins, observed=True)["Customer_Rating"].mean()),
        "insights": build_insights(d),
    })


@app.route("/api/orders")
def orders():
    d = filtered()
    q = request.args.get("q", "").strip().lower()
    if q:
        d = d[d["Order_ID"].str.lower().str.contains(q) | d["Customer_ID"].str.lower().str.contains(q)]
    sort = request.args.get("sort", "Date")
    if sort in TABLE_COLS:
        d = d.sort_values(sort, ascending=request.args.get("dir", "desc") == "asc")
    page = max(int(request.args.get("page", 1)), 1)
    size = 12
    rows = d[TABLE_COLS].iloc[(page - 1) * size: page * size].copy()
    rows["Date"] = rows["Date"].dt.strftime("%Y-%m-%d")
    return jsonify({"rows": rows.to_dict("records"), "total": int(len(d)), "page": page, "size": size})


@app.route("/download")
def download():
    d = filtered().drop(columns=["Month", "Age_Group", "Gross_Amount", "Customer_Type"])
    return Response(d.to_csv(index=False), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=filtered_orders.csv"})


if __name__ == "__main__":
    app.run(debug=True)
