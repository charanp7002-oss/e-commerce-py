# Shopper Behavior Dashboard

Flask (Python) backend + HTML/CSS/JavaScript frontend for the e-commerce customer behavior dataset.

## Run
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 (internet needed once for Chart.js and Google Fonts).

## Structure
- app.py: loads the CSV with pandas, filters it, serves JSON from /api/meta, /api/dashboard, /api/orders and /download
- templates/index.html: page layout
- static/css/style.css: theme
- static/js/app.js: filters, charts and order table
- data/: the dataset
