const P = ["#F4B63F", "#4CC9B0", "#E8643C", "#6F9BE8", "#D9455B", "#A3C46E", "#C98B5B", "#D9C79A"];
const TEXT = "#9FC4C7", GRID = "rgba(159,196,199,.18)";
const $ = id => document.getElementById(id);
const form = $("filters");
const charts = {};
let tbl = { page: 1, sort: "Date", dir: "desc" };

Chart.defaults.color = TEXT;
Chart.defaults.font.family = "Figtree, system-ui, sans-serif";
Chart.defaults.maintainAspectRatio = false;
if (matchMedia("(prefers-reduced-motion: reduce)").matches) Chart.defaults.animation = false;

const compact = n => new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(n);
const full = n => new Intl.NumberFormat("en").format(Math.round(n));

function query() {
  const p = new URLSearchParams();
  new FormData(form).forEach((v, k) => v && p.set(k, v));
  return p;
}

function draw(id, config) {
  charts[id]?.destroy();
  charts[id] = new Chart($(id), config);
}

const axes = (money = false) => ({
  x: { grid: { display: false } },
  y: { grid: { color: GRID }, beginAtZero: true, ticks: { callback: v => money ? compact(v) : v } },
});

function render(d) {
  const k = d.kpis;
  $("k-revenue").textContent = compact(k.revenue);
  $("k-orders").textContent = full(k.orders);
  $("k-aov").textContent = full(k.aov);
  $("k-rating").textContent = k.rating.toFixed(2);
  $("k-returning").textContent = k.returning + "%";
  $("k-discount").textContent = k.discount_rate + "%";
  $("subtitle").textContent = `${full(k.orders)} orders in view. Average delivery takes ${k.delivery} days.`;
  $("insights").innerHTML = d.insights.map(t => `<li>${t}</li>`).join("");

  draw("c-monthly", {
    type: "line",
    data: { labels: d.monthly.labels, datasets: [{ label: "Revenue", data: d.monthly.revenue,
      borderColor: P[0], backgroundColor: P[0], pointRadius: 4, tension: .3, borderWidth: 3 }] },
    options: { plugins: { legend: { display: false } }, scales: axes(true) },
  });
  draw("c-category", {
    type: "bar",
    data: { labels: d.category.labels, datasets: [{ data: d.category.values, backgroundColor: P, borderRadius: 4 }] },
    options: { indexAxis: "y", plugins: { legend: { display: false } },
      scales: { x: axes(true).y, y: { grid: { display: false } } } },
  });
  draw("c-city", {
    type: "bar",
    data: { labels: d.city.labels, datasets: [{ data: d.city.values, backgroundColor: P[1], borderRadius: 4 }] },
    options: { plugins: { legend: { display: false } }, scales: axes(true) },
  });
  const donut = (id, s) => draw(id, {
    type: "doughnut",
    data: { labels: s.labels, datasets: [{ data: s.values, backgroundColor: P, borderColor: "#1F5463", borderWidth: 3 }] },
    options: { cutout: "58%", plugins: { legend: { position: "bottom", labels: { boxWidth: 12 } } } },
  });
  donut("c-payment", d.payment);
  donut("c-device", d.device);
  draw("c-age", {
    type: "bar",
    data: { labels: d.age.labels, datasets: [{ data: d.age.values, backgroundColor: P[3], borderRadius: 4 }] },
    options: { plugins: { legend: { display: false } }, scales: axes(true) },
  });
  draw("c-rating", {
    type: "bar",
    data: { labels: d.rating.labels.map(r => r + " star"), datasets: [{ data: d.rating.values,
      backgroundColor: [P[4], P[2], P[0], P[5], P[1]], borderRadius: 4 }] },
    options: { plugins: { legend: { display: false } }, scales: axes() },
  });
  draw("c-delivery", {
    type: "bar",
    data: { labels: d.delivery_rating.labels, datasets: [{ data: d.delivery_rating.values, backgroundColor: P[6], borderRadius: 4 }] },
    options: { plugins: { legend: { display: false } },
      scales: { x: { grid: { display: false }, title: { display: true, text: "Days to deliver" } },
                y: { grid: { color: GRID }, min: 0, max: 5 } } },
  });
}

const COLS = [["Order_ID", "Order"], ["Date", "Date"], ["City", "City"], ["Product_Category", "Category"],
  ["Quantity", "Qty"], ["Total_Amount", "Total"], ["Payment_Method", "Payment"], ["Device_Type", "Device"],
  ["Customer_Rating", "Rating"]];

function head() {
  $("thead").innerHTML = COLS.map(([c, l]) =>
    `<th data-col="${c}" class="${tbl.sort === c ? "sorted" : ""}">${l}${tbl.sort === c ? (tbl.dir === "asc" ? " ▲" : " ▼") : ""}</th>`).join("");
}

async function loadTable() {
  const p = query();
  p.set("page", tbl.page); p.set("sort", tbl.sort); p.set("dir", tbl.dir);
  if ($("q").value) p.set("q", $("q").value);
  const r = await (await fetch("/api/orders?" + p)).json();
  head();
  $("tbody").innerHTML = r.rows.map(o => "<tr>" + COLS.map(([c]) =>
    `<td class="${c === "Total_Amount" || c === "Quantity" ? "num" : ""}">${c === "Total_Amount" ? o[c].toLocaleString("en", { minimumFractionDigits: 2 }) : o[c]}</td>`).join("") + "</tr>").join("");
  const pages = Math.max(Math.ceil(r.total / r.size), 1);
  $("pageinfo").textContent = `Page ${r.page} of ${pages} (${full(r.total)} orders)`;
  $("prev").disabled = r.page <= 1;
  $("next").disabled = r.page >= pages;
}

async function refresh() {
  const p = query();
  $("download").href = "/download?" + p;
  const d = await (await fetch("/api/dashboard?" + p)).json();
  $("empty").hidden = !d.empty;
  $("content").hidden = d.empty;
  if (d.empty) { $("subtitle").textContent = "0 orders in view."; return; }
  render(d);
  tbl.page = 1;
  loadTable();
}

async function init() {
  const m = await (await fetch("/api/meta")).json();
  for (const name of ["category", "city", "device", "gender"]) {
    const label = { category: "All categories", city: "All cities", device: "All devices", gender: "All genders" }[name];
    form[name].innerHTML = `<option value="">${label}</option>` + m[name].map(v => `<option>${v}</option>`).join("");
  }
  form.start.min = form.end.min = m.start;
  form.start.max = form.end.max = m.end;
  form.addEventListener("change", refresh);
  form.addEventListener("reset", () => setTimeout(refresh));
  $("q").addEventListener("input", () => { tbl.page = 1; loadTable(); });
  $("prev").onclick = () => { tbl.page--; loadTable(); };
  $("next").onclick = () => { tbl.page++; loadTable(); };
  $("thead").addEventListener("click", e => {
    const c = e.target.dataset.col;
    if (!c) return;
    tbl.dir = tbl.sort === c && tbl.dir === "desc" ? "asc" : "desc";
    tbl.sort = c; tbl.page = 1; loadTable();
  });
  refresh();
}
init();
